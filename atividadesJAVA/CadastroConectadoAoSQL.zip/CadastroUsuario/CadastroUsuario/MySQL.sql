CREATE DATABASE lojaJogos;
USE lojaJogos;

CREATE TABLE usuario(
nome  VARCHAR(50),
idade INT);

SELECT * FROM usuario;