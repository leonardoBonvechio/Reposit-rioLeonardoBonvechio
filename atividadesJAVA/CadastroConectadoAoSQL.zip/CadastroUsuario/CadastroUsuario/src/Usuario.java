
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Usuario {
  // tipos acesso:
  // public: onde todo o programa consegue enxergar aquele 
  //     atributo(variável)
  // private: onde apenas a classe origem (neste caso, Usuario) 
  //     consegue ver aquele atributo
  private String nome;
  private int    idade;
   
  // construtor
  // método(ação) que será executado no momento em que for criada a 
  //    instância (variável) do tipo Usuario
  public Usuario(String nomeC, int idadeC){
    this.nome  = nomeC;
    this.idade = idadeC;
  }
  
  // quando criamos atributos privados, para colocar valor neles, 
  //     precisamos usar métodos get/set.
  // get serve para PEGAR valores
  // set serve para COLOCAR valores
  // void significa que o método NÃO RETORNA valores
  public void setNome(String nomeP){
    this.nome = nomeP;
  }
  
  public void setIdade(int idadeP){
    this.idade = idadeP;
  }
  
  public String getNome(){
    return this.nome;
  }
  
  public int getIdade(){
    return this.idade;
  }
  
  public void gravaDados(){
    Connection conexaoBD = null;
    
    //try serve para tratar a aplicação se der erro
    try{
      // carregar a classe do BD
      Class.forName("com.mysql.cj.jdbc.Driver");
        
      //conectar-me ao BD
      conexaoBD = DriverManager.getConnection(
        "jdbc:mysql://localhost/CadastroUsuario?useTimezone=true&"+
        "serverTimezone=UTC", "root", "");
        
      PreparedStatement inseridor = null;
      inseridor = conexaoBD.prepareStatement(
        "INSERT INTO usuario (nome, idade)" + 
                     " VALUES(?,    ?); ");
        
      inseridor.setString(1, nome);
      inseridor.setInt(2, idade);
        
      inseridor.executeUpdate();
        
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
    } catch (SQLException ex) {
          Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
      }
  }
}
