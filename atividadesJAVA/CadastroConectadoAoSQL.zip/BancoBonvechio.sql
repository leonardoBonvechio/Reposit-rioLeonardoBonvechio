create database CadastroUsuario;
use CadastroUsuario;

create table Usuario(
nome varchar(50),
idade int);
select * from Usuario;



create database CadastroJogos;
use CadastroJogos;

create table Jogos(
nome varchar(50),
desenvolvedora varchar(50),
classificacao int,
genero varchar(50),
preco float);
 
 select * from Jogos;

create database Cliente;
use Cliente;

create table Cliente(
nome varchar(50),
CPF int,
endereco varchar(50),
Datax varchar(50));

select * from Cliente
