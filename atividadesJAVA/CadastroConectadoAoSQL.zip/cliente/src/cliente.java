
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aluno
 */
public class cliente {
    private String nome;
    private String Datax;
    private int cpf;
    private String endereco;
    
    public cliente(int cpfC){
        this.cpf = cpfC;
    }
    
    public cliente (String nomeC, String data, 
                    int cpfC , String enderecoC){
        
        this.nome     = nomeC;
        this.Datax = data;
        this.cpf      = cpfC;
        this.endereco = enderecoC;
    }    
    
    public void setNome(String nomeP){
        this.nome = nomeP;
    }
    
    public void setDataNasc(String dataNascP){
        this.Datax = dataNascP;
    }
    
    public void setEndereco(String enderecoP){
        this.endereco = enderecoP;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public String getDataNasc(){
        return this.Datax;
    }
    
    public int getCpf(){
        return this.cpf;
    }
    
    public String getEndereco(){
        return this.endereco;
    }

    void inserirDados() {
      try {      
          Connection conexaoBD = null;
          // carregar o driver para acesso ao BD
          Class.forName("com.mysql.cj.jdbc.Driver");
          
        conexaoBD = DriverManager.getConnection(
                  "jdbc:mysql://localhost/CadastroUsuario?useTimezone=true&"+
        "serverTimezone=UTC", "root", "");

          PreparedStatement inseridor = null;
          inseridor = conexaoBD.prepareStatement("INSERT INTO cliente(nome, Datax, " + "endereco, CPF)" + "VALUES(?, ?, ?, ?);");
          inseridor.setString(1, nome);
          inseridor.setString(2,Datax);
          inseridor.setString(3, endereco);
          inseridor.setInt(4, Integer.valueOf(cpf));
          inseridor.executeUpdate();
      } catch (ClassNotFoundException ex) {
          Logger.getLogger(cliente.class.getName()).log(Level.SEVERE, null, ex);
      } catch (SQLException ex) {
          Logger.getLogger(cliente.class.getName()).log(Level.SEVERE, null, ex);
      }
   } 
}
    


