CREATE DATABASE lojaJogos;
USE lojaJogos;

CREATE TABLE jogos(
  nome           VARCHAR(50),
  desenvolvedora VARCHAR(50),
  genero         VARCHAR(50),
  classificacao  INT,
  preco          FLOAT);