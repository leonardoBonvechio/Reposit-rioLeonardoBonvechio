
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Jogos {
  // vamos colocar as características de um jogo:
  String nome, desenvolvedora, genero;
  int    classificacaoEtaria;
  float  preco;
  
  // quando é criado um atributo do tipo jogos, ele
  //   executará o construtor automaticamente
  //  O construtor tem o mesmo nome da classe
  public Jogos(String nomeC,   String desenvolvedoraC,
               String generoC, int classificacaoEtariaC,
               float  precoC){
    this.nome                = nomeC;
    this.desenvolvedora      = desenvolvedoraC;
    this.genero              = generoC;
    this.classificacaoEtaria = classificacaoEtariaC;
    this.preco               = precoC;
  }
  
  // Método para inserir os dados no BD
  public void inserirDados(){
      // Importar a conexão dos dados
      Connection conexaoBD = null;
      try {
          // carregar o driver para acesso ao BD
          Class.forName("com.mysql.jdbc.Driver");
          
          conexaoBD = DriverManager.getConnection(
                  "jdbc:mysql://localhost/CadastroJogos", "root", "");
      } catch (ClassNotFoundException ex) {
          Logger.getLogger(Jogos.class.getName()).log(Level.SEVERE, null, ex);
      } catch (SQLException ex) {
          Logger.getLogger(Jogos.class.getName()).log(Level.SEVERE, null, ex);
      }
  }
}
